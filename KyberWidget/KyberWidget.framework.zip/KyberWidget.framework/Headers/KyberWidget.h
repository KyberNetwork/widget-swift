//
//  KyberWidget.h
//  KyberWidget
//
//  Created by Manh Le on 27/8/18.
//  Copyright © 2018 kyber.network. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for KyberWidget.
FOUNDATION_EXPORT double KyberWidgetVersionNumber;

//! Project version string for KyberWidget.
FOUNDATION_EXPORT const unsigned char KyberWidgetVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KyberWidget/PublicHeader.h>


